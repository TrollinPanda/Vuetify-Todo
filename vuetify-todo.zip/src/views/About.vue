<template>
  <div class="about pa-6">
    <h1>About Vuetify Todo</h1>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi, in alias?
      Cumque quis vitae, veritatis perferendis cum ex excepturi animi blanditiis
      quidem deserunt iusto doloremque laborum alias facilis quam nemo.
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi, in alias?
      Cumque quis vitae, veritatis perferendis cum ex excepturi animi blanditiis
      quidem deserunt iusto doloremque laborum alias facilis quam nemo.
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi, in alias?
      Cumque quis vitae, veritatis perferendis cum ex excepturi animi blanditiis
      quidem deserunt iusto doloremque laborum alias facilis quam nemo.
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi, in alias?
      Cumque quis vitae, veritatis perferendis cum ex excepturi animi blanditiis
      quidem deserunt iusto doloremque laborum alias facilis quam nemo.
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi, in alias?
      Cumque quis vitae, veritatis perferendis cum ex excepturi animi blanditiis
      quidem deserunt iusto doloremque laborum alias facilis quam nemo.
    </p>
  </div>
</template>
